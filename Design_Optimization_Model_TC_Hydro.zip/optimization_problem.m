%% Optimization Model %%
% Goal - Define Optimal Parameters for a bioretention design
% Developer: Marcus Nobrega
% Date: 6/3/2022
% Next step - Implement non-linear boundary condtions on the perimeter

%% Genetic Algorithm Optimization Problem
clear all
tic
pop_size = 10; % size of the population
generations = 10; % number of generations
stall_generations = 10; 
tolerance = 1e-6;
stall_limit = 5*60; % If no improvement is found in this time in seconds, the algorithm stops.
% Decision Vector
% x = [ATC, P, Ld, p, ksat, dtheta, psi]^T
%%%% Minimum and Maximum Perimeter %%%%
Ratio = 10; % L/B = Ratio
% Pmin = pi*sqrt(4*x(1)/pi);
% Technically, Pmax should be written as:
% Pmax = 2*sqrt(x(1)/Ratio)*(1 + Ratio);
% However, this is a non-linear contraint with an linear upper bound of
% 2/sqrt(Ratio) * x(1) * (1 + Ratio). Herein, for simplification, if we
% have a mimum area A_min, the lower bound for the perimeter is given in
% terms of A_min. Similarly, the upper bound is determined.

% Entering another boundary values
% x = [ATC, P, Ld, p, ksat, dtheta, psi]^T
A_min = 100; % m2
A_max = 1000; % m2
P_min = pi*sqrt(4*A_min/pi); % Calculated
P_max = 2*sqrt(A_max/Ratio)*(1+Ratio); % Calculated
Ld_min = 0.5; % m
Ld_max = 2; % m
p_min = 0; % m
p_max = 0.4; % m
ksat_min = 10; % mm/hr
ksat_max = 100; % mm/hr
dtheta_min = 0.15;
dtheta_max = 0.35;
psi_min = 110; % mm
psi_max = 220; % mm

nvars = 7; % number of variables (i.e.,
A = []; % Inequality constraint given by A*x <= b
b = []; 
Aeq = []; % Equality constraint given by Aeq*x = beq
beq = []; % 
lb = [A_min P_min Ld_min p_min ksat_min dtheta_min psi_min];
ub = [A_max P_max Ld_max p_max ksat_max dtheta_max psi_max];
nonlcon = []; % Non-linear constraints of x (function of x)
intcon = []; % Integer only constraints of x
options = optimoptions('ga','PlotFcns', {@gaplotbestf,@gaplotstopping},'PopulationSize',pop_size,'Generations',generations,'StallTimeLimit',stall_limit,'MaxStallGenerations',stall_generations,'FunctionTolerance',tolerance);
fun = @(x)fitness(x);
% GA problem
[x,fval,exitflag,output,population,scores] = ga(fun,nvars,A,b,Aeq,beq,lb,ub,nonlcon,intcon,options);
toc
final_values = [pop_size, generations, x, toc, fval];