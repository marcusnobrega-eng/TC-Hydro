function [OF] = fitness(x)
%% Matlab Bioretention Model
% Developer: Marcus Nobrega
% Date: 5/28/2022
% Optimization model
% Goal - Define Fitness Function for the Optimization Problem

% x = [ATC, P, Ld, p, ksat, dtheta, psi]^T
ATC = x(1);
perimeter = x(2);
Ld = x(3);
h_weir = x(4);
ksat = x(5);
dtheta = x(6);
psi = x(7);

% Evaluation Function Parameters
%%%% OF =
peak_flow_limit = 0.60;
hmax = 0.35; % m
k1 = 40; % USD/m3
k2 = 50; % USD/m2
k3 = 20; % USD/m2
k4 = 0; % USD/m2
k5 = 100000000000; % USD/m
k6 = 100000000000; % USD/m

% OF = k1*(ATC*Ld) + k2*(ATC) + k3*perimeter*Ld + k4*(h_weir*ATC) + k5*peak_flow + k6*(max(max(h) - hmax,0))
%%% Orifice rating curve
k_o1_o = 1000*0.002365638; % Attention here
k_o2_o = 0.5;
h_orifice = 0.0; % Height of orifice taken from the bottom of the media in (m)
%%% weir rating curve (Q = k_01 * (h - p) ^ k_02)
k_o1_w = 1.8;
k_o2_w = 3/2;
% Boundary soil properties
ksat_b = 0; % Infiltration rate of bottom soil in mm/hr;
ksat_l = 0; % Infiltration rate of lateral soil in mm/hr;
%% Inputs
% Model
dt = 10; % Model time-step in seconds
TT = 36*60; % simulation end in minutes
% Rainfall and ETR (Akan)
Rainfall_time = 3; % hours
Tp = 2/3; % hr
Qb = 0; % m3/s;
Qp = 0.06; % m3/s;
Beta = 2;
Inflow_Hydrograph_fun = @(t)(Qb + (Qp - Qb).*(t/(Tp).*exp(1 - (t)/(Tp))).^Beta);
time_inputs = [5]'; % Input interval time in minutes
time_inflow = [0:time_inputs:Rainfall_time*60]/60;
time_inflow(1,1) = 1/60/60;
for ii = 1:length(time_inflow)
    tt = time_inflow(ii);
    q_r(ii,1) = Inflow_Hydrograph_fun(tt);
end
% Delta time
delta_time = TT/60 - Rainfall_time; % hours
dim_extra_time = delta_time*60*60/dt;
%% Attention here
q_r_cfs = q_r*35.3146667;
i_t = zeros(size(q_r_cfs));
q_etr = i_t;

% % Fill other variables as 0
dim_data = dim_extra_time;
i_t(end:(end + dim_data),1) = 0;
q_etr(end:(end + dim_data),1) = 0;
q_r(end:(end + dim_data),1) = 0;

% Outlet devices
q_o_up = @(L)(k_o1_o.*(max(L - h_orifice,0)).^(k_o2_o));
q_o_down = @(L)(k_o1_o.*(max(L - (Ld - h_orifice),0)).^(k_o2_o));
%%% Weir rating curve
% h_weir = 0.35; % Height of the weir taken from top media in meters (ATTENTION HERE)
q_w = @(h)(k_o1_w.*(max(h - h_weir,0)).^(k_o2_w));
%% Calculations
% Number of time-steps
Nt = TT*60/dt;
time_index = [1:1:Nt];
time = [dt:dt:Nt*dt]/dt;
time = [0 time]; % Adding first value as time equals 0
time_inputs_vector = [1:1:length(i_t)]*time_inputs*60/dt;
time_inputs_vector(1,1) = 1; % Number of time-steps
% %% DAE Dynamics
% E = [ones(3) zeros(3,5) ; zeros(5,3) zeros(5)];
% A = [ones(3) zeros(3,5) ; zeros(5,3)  -ones(5)];
%% Explicit Numerical Scheme Solver
% Net Inflow
net_inflow = (i_t - q_etr)/1000/3600*ATC + q_r; % Flow in m3/s
q_in = interp1(time_inputs_vector,net_inflow,time,'pchip')'; % Flow in m3/s at model's time-step
q_in = max(q_in,0); % Negative flow boundary condition
% Net Rainfall
net_rainfall = interp1(time_inputs_vector/dt,(i_t - q_etr),time/dt,'pchip')'; % Flow in mm/hr at model's time-step
net_rainfall = max(net_rainfall,-q_etr(end));
% Pre-allocating Arrays
dim = zeros(Nt,1);
Lt = dim; h = dim; S = dim; C = dim; p_t = dim; q_inf = dim; q_exf = dim; out_o = dim; out_w = dim; q_per = dim;
% Man Loop
%%% Initial Boundary Conditions
h(1,1) = 0; % cm
Lt(1,1) = psi/1000; % m
Vin_t = Lt(1,1)*ATC*dtheta; % m3
% Storage
S(1,1) = ATC*Lt(1,1)*dtheta + ATC*h(1,1);
q_in(end+1,1) = q_in(end,1); % Boundary
for i = 1:(Nt)
    %     tt = i*dt/60;
    % Inflow Rate
    p_t(i,1) = ((q_in(i,1) + q_in(i+1))/(2*ATC) + h(i,1)/dt); % m/sec
    if p_t(i,1) < 1/1000/3600 % Precision of 1 mm/hr
        p_t(i,1) = 0;
    end
    % Vin_star
    Vin_star_end = Vin_t + 0.5*(q_in(i+1) + q_in(i))*dt; % m3
    % L_star
    L_star_dividing = 1/Lt(i,1) + 1/(min(Lt(i,1) + (Vin_star_end - Vin_t)/(2*ATC*dtheta),Ld));

    % Infiltration Rate
    if p_t(i,1) > 0 % Inflow and/or rainfall
        % Infiltration Capacity
        if Lt(i,1) > Ld - h_orifice
            sf = 0;
        else
            sf = 1;
        end
        C(i,1) = 1/2*ksat/1000/3600*(2 + (sf*psi/1000 + h(i,1)*L_star_dividing));
        if p_t(i,1) < C(i,1)
            q_inf(i,1) = p_t(i,1)*ATC; % m3/s
        else
            q_inf(i,1) = C(i,1)*ATC;
        end
        q_per(i,1) = q_inf(i,1); % Assuming percolation as the same as infiltration
    else
        sf = -1;
        q_per(i,1) = ksat*(Lt(i,1) + sf*psi/1000)/(Lt(i,1))/1000/3600*ATC; % Assuming percolation as the same as infiltration
        C(i,1) = 0;
        q_inf(i,1) = 0;
    end

    if Lt(i,1) == 0 && p_t(i,1) == 0
        q_per(i,1) = 0;
    end
    if max(Lt(1:i,1)) == Ld
        q_exf(i,1) = ATC*ksat_b/1000/3600*((h(i,1) + Lt(i,1))/Lt(i,1)) + ksat_l/1000/3600*perimeter*(h(i,1) + Lt(i,1)/2)/(Lt(i,1)/2); % Check here later (m/s)
    else
        q_exf(i,1) = ksat_l/1000/3600*perimeter*(h(i,1) + Lt(i,1)/2)/(Lt(i,1)/2); % Check here later (m/s)
    end
    % Outflows
    % Orifice
    if max(Lt(1:i,1)) < (Ld - h_orifice) && p_t(i,1) > 0
        % Downward movement
        out_o(i,1) = 0;
    elseif max(Lt(1:i,1)) >= (Ld - h_orifice) && p_t(i,1) > 0 % Infiltration still occuring
        % Upward movement
        out_o(i,1) = q_o_up(Lt(i,1));
        % Infiltration Constraint at Orifice
        out_o(i,1) = min(ksat/1000/3600*ATC*(Lt(i,1) + h(i,1))/(Lt(i,1)),out_o(i,1));
        if out_o(i,1) == 0
            out_o(i,1) = 0;
        end
    elseif max(Lt(1:i,1)) >= (Ld - h_orifice) && h(i,1) < 1e-3 % ATTENTION HERE
        out_o(i,1) = q_o_up(Lt(i,1));
        % Infiltration Constraint at Orifice
        out_o(i,1) = min(ksat/1000/3600*ATC*(Lt(i,1) - psi/1000)/(Lt(i,1)),out_o(i,1));
        if out_o(i,1) == 0
            out_o(i,1) = 0;
        end
    end

    % Weir
    out_w(i,1) = q_w(h(i,1));
    % Check Dynamical Case
    check = 0;
    %     if q_in(i,1) > 0 || h(i,1) > 0
    if p_t(i,1) > 0
        check = 1;
    end
    % Alternative 1 - ODE45 solver
    %     tspan = [0 dt];
    %     x0 = [Lt(i,1), h(i,1), S(i,1)];
    %     %     bioret_dynamics(t,x_t,q_in(i,1),q_inf(i,1),out_o(i,1),out_w(i,1),q_exf(i,1),dtheta,ATC)
    %     [~,x_t] = ode45(@(t,x_t)bioret_dynamics(t,x_t,q_in(i,1),q_inf(i,1),out_o(i,1),out_w(i,1),q_exf(i,1),dtheta,ATC,check),tspan,x0);
    %     x_t = x_t(end,:); % Getting only the last values of x_t
    %     % Defining Parameters of the Next Time-Step
    %     Lt(i+1,1) = x_t(1,1);
    %     h(i+1,1) = x_t(1,2);
    %     S(i+1,1) = x_t(1,3);
    %     Vin_t = ATC*Lt(i+1,1)*dtheta;

    % Alternative 2 - Solving with Euler Explicit Scheme
    % dx/dt = (x(i+1) - x(i))/dt
    % x(i+1) = x(i) + alfa*dt;
    % Imposing Numerical Constraint in Lt
    Lt(i+1,1) = Lt(i,1) + 1/(ATC*dtheta)*(check*q_inf(i,1) - out_o(i,1) - q_exf(i,1))*dt;
    alfa = Lt(i+1,1);
    if Lt(i+1,1) > Ld
        Lt(i+1,1) = Ld;
        h(i+1,1) = h(i,1) + 1/ATC*(q_in(i,1) - out_w(i,1) - check*q_inf(i,1))*dt + (alfa - Ld)*dtheta;
        S(i+1,1) = ATC*dtheta*Lt(i+1,1) + ATC*h(i+1,1); % Nothing was changed
    else
        h(i+1,1) = h(i,1) + 1/ATC*(q_in(i,1) - out_w(i,1) - check*q_inf(i,1))*dt;
        S(i+1,1) = ATC*dtheta*Lt(i+1,1) + ATC*h(i+1,1);
        Vin_t = ATC*Lt(i+1,1)*dtheta;
    end

    if Lt(i,1) < psi/1000
        Lt(i,1) = psi/1000; % Attention here
    end
end

%% Mass Balance Checkings
% inflow_volumes = sum(q_in)*dt + ATC*dtheta*Lt(1,1);
% outflow_volumes = sum((out_o + out_w + q_exf))*dt;
% mass_balance_error = inflow_volumes - outflow_volumes - Lt(end,1)*ATC*dtheta;
%% Evaluation Functions
q_tot = out_o + out_w + q_exf;
peak_flow_reduction = (max(q_in) - max(q_tot))/max(q_in);
if peak_flow_reduction < peak_flow_limit
    peak_flow = abs(peak_flow_reduction);
else
    peak_flow = 0;
end
OF = k1*(ATC*Ld) + k2*(ATC) + k3*perimeter*Ld + k4*(h_weir*ATC) + k5*peak_flow + k6*(max(max(h) - hmax,0));
end
